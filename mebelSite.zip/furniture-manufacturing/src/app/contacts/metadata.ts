import { Metadata } from "next"

export const metadata: Metadata = {
  title: "Контакты | МебельПро",
  description: "Свяжитесь с нами для получения консультации или заказа мебели. Телефоны, адрес и форма обратной связи.",
}
